package controller;

import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDAO;
import model.User;

@WebServlet("/updateUser")
public class UpdateUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	final Logger logger = Logger.getLogger(AddUserServlet.class.getName());
    	
        // Step 1: Get data from the request
        String id = request.getParameter("id");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String nic = request.getParameter("nic");
        String address = request.getParameter("address");
        String role = request.getParameter("role");

        // Step 2: Create a User object with the updated data
        User updatedUser = new User();
        updatedUser.setId(Integer.parseInt(id));
        updatedUser.setFirstName(firstName);
        updatedUser.setLastName(lastName);
        updatedUser.setEmail(email);
        updatedUser.setPhone(phone);
        updatedUser.setNic(nic);
        updatedUser.setAddress(address);
        updatedUser.setRole(role);

        // Step 3: Call DAO to update the user in the database
        UserDAO userDao = new UserDAO();
        boolean isUpdated = userDao.updateUser(updatedUser);

        // Step 4: If update is successful, redirect or forward accordingly
        if (isUpdated) {
        	 logger.info("Updted user Information correctly");
            request.getRequestDispatcher("update-success.jsp").forward(request, response);// Redirect to the users list page (or any other page)
        } else {
            request.setAttribute("error", "Failed to update user details");
            request.getRequestDispatcher("edit.jsp").forward(request, response);
        }
    }
}
